import numpy as np
import pandas as pd


#def sigmoid(z):
    #return 1.0/(1.0+np.exp(-z))


def feedforward(x, w, b):
    #a = sigmoid(np.dot(w, x) + b)
    a = np.dot(w, x) + b
    return a


def predict(x, w, b):
    #x = x.reshape(-1, 1)
    a = feedforward(x, w, b)
    if(a>0.5):
        return 1
    return 0


#reading data and spliting it to train and test set
df = pd.read_csv('IRIS2.csv').sample(frac=1) #reading and shuffling data 
msk = np.random.rand(len(df)) < 0.75

train = df[msk]
test = df[~msk]
#print(test,'\n\n\n')
#print(train)


train_y = train['species'].values
test_y = test['species'].values

train_x = train.drop(columns = ['species']).values
test_x = test.drop(columns = ['species']).values


# initializing weight vector
input_size = len(train_x[0])
w, b = np.zeros((1, input_size)), 0
lr, epochs = 0.1, 20


def Training(X, Y, w, b, lr, epochs):
    for t in range(epochs):
        for i in range(len(X)):
            x, y = X[i], Y[i]
            y_pred = predict(x, w, b)
            if(y - y_pred != 0):
                w = w + lr*(y - y_pred)*X[i]
                b = b + lr*(y - y_pred)
            print(i,'\t\t\t' ,"Epoch:  ",t,'\t\t\t',"actual:  ",y,'\t\t\t',"Input",x, '\t\t\t',"Predicted: ",y_pred,"Weights: ", w, '\t\t\t', "Threshold: ",b) 
            
    return w, b



# using Training to train the perceptron on training dataset
w, b = Training(train_x, train_y, w, b, lr, epochs)


# Using perceptron to predict for test dataset
print('True Output\t', 'predicted Output')
for i in range(len(test_x)):
    x, y = test_x[i], test_y[i]
    y_pred = predict(x, w, b)
    print(y, '\t\t\t', y_pred)
